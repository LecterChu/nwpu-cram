#include<cstdio>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;

const int maxn = 25;
int n,m;
int a[maxn],b[maxn];
int c[maxn*2],cnt = 0; //  cnt是 c数组 的下标指针
void merge() // 合并 a和b 数组 
{
	int p = 0,t = 0; // p,t 分别为a，b数组的下标指针
	while(p < n && t < m)
	{
		if(a[p] < b[t]) 
		{
			c[cnt++] = a[p++];
		}
		else
		{
			if(a[p] > b[t])
			{
				c[cnt++] = b[t++];
			}
			else
			{
				c[cnt++] = a[p];
				c[cnt++] = b[t];
				p++,t++;
			}
		}
	}
	while(p < n) c[cnt++] = a[p++];
	while(t < m) c[cnt++] = b[t++];
}
int main()
{
	scanf("%d",&n);
	for(int i=0;i<n;i++) scanf("%d",&a[i]); //输入a数组
	scanf("%d",&m); 
	for(int i=0;i<m;i++) scanf("%d",&b[i]); //输入b数组
	merge();  // 合并 a 和 b 到 c
	for(int i=0;i<cnt;i++)
	{
		printf("%d\n",c[i]);
	}
	return 0;
}
