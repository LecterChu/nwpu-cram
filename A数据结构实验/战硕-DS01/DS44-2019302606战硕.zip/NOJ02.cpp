#include<cstdio>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;

const int maxsize = 600;  // 设定求小数点后多少位
typedef struct node  // 双向链表的结构体
{
    
    int data;
    struct node *nxt;
    struct node *pre;
    struct node *tail;
    node()              //构造函数，用于初始化
    {
        data = 0;
        tail  = this;
        nxt = NULL;
        pre = NULL;
    }
    
}Node,*List;

void Mult(List Head,int k);      // 对链表每一位 *k
void Divi(List Head,int k);      // 对链表每一位 ÷k
void Sum(List a,List b);         // 对两个链表的数求和，所得数放在前面链表中
void InitList(List &L);          // 初始化链表，并把第一个节点值设为 1
List CopyList(List L);           // 复制一个一模一样的链表
void InitSum(List &L);           // 初始化最后存和的链表，并把第一个节点置为1
void Output(List L,int k);       // 输出一个链表，保留 k 位小数


int main()
{
    int n = 0;
    scanf("%d",&n);             
    List Head,S;
    InitList(Head);
    InitSum(S);
    for(int i=2;i<=3000;i++)     //计算pi值
    {
        Mult(Head,i-1);
        Divi(Head,2*i-1);
        Sum(S,Head);
    }
    
    Mult(S,2);
    Output(S,n);
    return 0;
}

void Mult(List Head,int k)    // 对以Head为头节点的链表中的每一位做乘法
{
    List p = Head->tail;      // 先把指针指向链表的末尾，方便从后往前做乘法
    while(p != Head)          // 从前往后开始算乘法
    {
        p->data *= k;
        p = p->pre;
//      printf("I have done Multi.\n");
    }
    p = Head->tail;
    while(p != Head->nxt)     //开始处理进位 
    {
        p->pre->data += p->data /10;
        p->data %= 10;
        p = p->pre;
    }
    while( p->data > 10)      //一直处理最高位的进位 
    {
        List s = (List)malloc(sizeof(Node));
        s->data = p->data/10;
        p->data %= 10;
        s->pre = Head;
        s->nxt = p;
        p->pre = s;
        Head->nxt = s;
        p = s;
    }
}

void Divi(List Head,int k) // 对链表每一位除k
{
    int temp = 0,depth = 0;     //temp用于进位计算 ，depth 用于计算链表长度
    List p = Head->nxt;
    List t;                     // 存尾部节点
    while(p != NULL)            //模拟做除法
    {
        depth++; 
        p->data += temp*10; 
        temp = p->data % k;
        p->data /= k;
        t = p;
        p = p->nxt;
    }
    p = t;
    while(temp!=0 && depth <= maxsize)  // 如果除不尽，就一直往后拓展节点，但注意不要超过最大位数
    {
//      printf("I have done Division!\n");
        depth++;
        List s = (List)malloc(sizeof(Node));
        s->data = temp*10;
        s->nxt = NULL;
        s->pre = p;
        temp = s->data % k;
        s->data /= k;
        p->nxt = s;
        p = s;
    }
    Head->tail = p;
}

void Sum(List a,List b)  // 对两个链表的数求和，所得数放在前面链表中
{
    List p = a->tail,k = b->tail;  // 先指向各自的尾部，开始从前往后加
    while(p!=a && k!=b)  // 遍历到有一个到头节点为止
    {
        p->data += k->data;
        p->pre->data += p->data / 10;
        p->data %= 10;
        p = p->pre;
        k = k->pre;
    }
}

void InitList(List &L) // 初始化链表，并把第一个节点值设为 1
{
   L = (List)malloc(sizeof(Node));
   L->data = 0;
   List s = (List)malloc(sizeof(Node));
   s->data = 1;
   s->pre = L;
   L->nxt = s;
   L->pre = NULL;
   L->tail = s;
   s->nxt = NULL; 
}

void InitSum(List &L) // 初始化最后存和的链表，并把第一个节点置为1
{
    L = (List)malloc(sizeof(Node));
    L->nxt = NULL;
    L->pre = NULL;
    L->data = 0;
    List p = L;
    int depth = 0;
    while(depth <= maxsize)
    {
        List s = (List)malloc(sizeof(Node));
        s->data = 0;
        s->pre = p;
        p->nxt = s;
        s->nxt = NULL;
        p = s;
        depth++;
    }
    L->nxt->data = 1;
    L->tail = p;
}

void Output(List L,int k) //输出一个列表，保留 k 位小数
{
    List p = L->nxt;
    printf("%d.",p->data);
    p = p->nxt;
    int t = 0;
    while(p != NULL && t<k) 
    {
        t++;
        printf("%d",p->data);
        p = p->nxt;
    }
    printf("\n");
}