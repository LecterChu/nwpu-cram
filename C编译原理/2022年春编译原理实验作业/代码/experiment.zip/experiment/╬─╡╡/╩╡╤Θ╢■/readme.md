# 实验二测试方法描述

[TOC]



## 测试用例

#### 语义分析用例

**用例放置在input/case_for_SemanticCheck/下**

##### **case1：**

```c++
module  space{
	struct A{
    	short a; 
	};
	struct A{
    	short b;
	};
};
```

**分析结果**：

<img src="E:\homework\experiment\文档\实验二\assets\image-20230618183039814.png" alt="image-20230618183039814" style="zoom:67%;" />

##### **case2：**

```c++
struct A{
	short num;
	long num;
};
```

**分析结果**：

<img src="E:\homework\experiment\文档\实验二\assets\image-20230618183107431.png" alt="image-20230618183107431" style="zoom:67%;" />

##### **case3：**

```c++
struct A{
	short a;
	B b;
};
```

**分析结果**：

<img src="E:\homework\experiment\文档\实验二\assets\image-20230618183125956.png" alt="image-20230618183125956" style="zoom:67%;" />

##### **case4：**

```c++
struct A{
	short a=“a”;
};
```

**分析结果**：

<img src="E:\homework\experiment\文档\实验二\assets\image-20230618183206789.png" alt="image-20230618183206789" style="zoom:67%;" />

##### **case5**：

```c++
struct A{
	short a=100000;
};
```

**分析结果**：

<img src="E:\homework\experiment\文档\实验二\assets\image-20230618183223094.png" alt="image-20230618183223094" style="zoom:67%;" />

##### **case6：**

```c++
struct A{
	short a[4]=[10,12,45.34,’a’];
};
```

**分析结果**：

<img src="E:\homework\experiment\文档\实验二\assets\image-20230618183251045.png" alt="image-20230618183251045" style="zoom:67%;" />



#### 代码生成用例

**用例放置在input/case_for_GenCode/下**

##### **case1：**

```c++
module space{
	struct A{
		short a=10;
	};
	struct B{
		long c=100;
		A d;
	};
};
```

**生成结果：**

```hxx
/*
WARNING: THIS FILE IS AUTO-GENERATED. DO NOT MODIFY.

This file was generated from case_for_GenCode.idl using "idltoc".
The idltoc tool is part of the RTI Data Distribution Service distribution.
For more information, type 'idltoc -help' at a command shell
or consult the RTI Data Distribution Service manual.
*/
#ifndef case_for_GenCode_h
#define case_for_GenCode_h

#ifndef rti_me_cpp_hxx
#include "rti_me_cpp.hxx"
#endif

#ifdef NDDS_USER_DLL_EXPORT
#if (defined(RTI_WIN32) || defined(RTI_WINCE))
/* If the code is building on Windows, start exporting symbols. */
#undef NDDSUSERDllExport
#define NDDSUSERDllExport __declspec(dllexport)
#endif
#else
#undef NDDSUSERDllExport
#define NDDSUSERDllExport
#endif

struct space_ASeq;
class space_ATypeSupport;
class space_ADataWriter;
class space_ADataReader;

class space_A
{
public:
    typedef struct space_ASeq Seq;
    typedef space_ATypeSupport TypeSupport;
    typedef space_ADataWriter DataWriter;
    typedef space_ADataReader DataReader;

        CDR_Short a = 10;

};

extern const char *space_ATYPENAME;

REDA_DEFINE_SEQUENCE_STRUCT(space_ASeq, space_A);

REDA_DEFINE_SEQUENCE_IN_C(space_ASeq, space_A);

NDDSUSERDllExport extern RTI_BOOL
space_A_initialize(space_A *sample)
{
    CDR_Primitive_init_Short(&sample->a);

    return RTI_TRUE;
}

NDDSUSERDllExport extern RTI_BOOL
space_A_finalize(space_A *sample)
{
    UNUSED_ARG(sample);
    return RTI_TRUE;
}


struct space_BSeq;
class space_BTypeSupport;
class space_BDataWriter;
class space_BDataReader;

class space_B
{
public:
    typedef struct space_BSeq Seq;
    typedef space_BTypeSupport TypeSupport;
    typedef space_BDataWriter DataWriter;
    typedef space_BDataReader DataReader;

        CDR_Long c;
        space_A d;

};

extern const char *space_BTYPENAME;

REDA_DEFINE_SEQUENCE_STRUCT(space_BSeq, space_B);

REDA_DEFINE_SEQUENCE_IN_C(space_BSeq, space_B);


NDDSUSERDllExport extern space_B()
{
       this->c = 100;
        this->d.a = 10;
}


NDDSUSERDllExport extern RTI_BOOL
space_B_initialize(space_B *sample)
{
    CDR_Primitive_init_Long(&sample->c);

        if (!space_A_initialize(&sample->d))
        {
            return RTI_FALSE;
        }


    return RTI_TRUE;
}

NDDSUSERDllExport extern RTI_BOOL
space_B_finalize(space_B *sample)
{
    UNUSED_ARG(sample);
            space_A_finalize(&sample->d);

    return RTI_TRUE;
}

#ifdef NDDS_USER_DLL_EXPORT
#if (defined(RTI_WIN32) || defined(RTI_WINCE))
/* If the code is building on Windows, stop exporting symbols. */
#undef NDDSUSERDllExport
#define NDDSUSERDllExport
#endif
#endif

#endif /* hxx */

```

##### **case2：**

```c++
module space{
	struct A{
		short i1=10;
		int16 i2=10;
		long i3=100;
		int32 i4=100;
		long long i5=1000;
		int64 i6=1000;
		unsigned short i7=10;
		uint16 i8=10;
		unsigned long i9=100;
		uint32 i10=100;
		unsigned long long i11=1000;
		uint64 i12=1000;
		char c0='a';
		string c1="abc";
		boolean c2=true;
		float c3=10.901f;
		double c4=23.234d;
		long double c5=12.23456432235d;
		short arr[10]=[0,1,2,3,4,5,6,7,8,9];
	};
};
```

**生成结果：**

```
/*
WARNING: THIS FILE IS AUTO-GENERATED. DO NOT MODIFY.

This file was generated from case_for_GenCode.idl using "idltoc".
The idltoc tool is part of the RTI Data Distribution Service distribution.
For more information, type 'idltoc -help' at a command shell
or consult the RTI Data Distribution Service manual.
*/
#ifndef case_for_GenCode_h
#define case_for_GenCode_h

#ifndef rti_me_cpp_hxx
#include "rti_me_cpp.hxx"
#endif

#ifdef NDDS_USER_DLL_EXPORT
#if (defined(RTI_WIN32) || defined(RTI_WINCE))
/* If the code is building on Windows, start exporting symbols. */
#undef NDDSUSERDllExport
#define NDDSUSERDllExport __declspec(dllexport)
#endif
#else
#undef NDDSUSERDllExport
#define NDDSUSERDllExport
#endif

struct space_ASeq;
class space_ATypeSupport;
class space_ADataWriter;
class space_ADataReader;

class space_A
{
public:
    typedef struct space_ASeq Seq;
    typedef space_ATypeSupport TypeSupport;
    typedef space_ADataWriter DataWriter;
    typedef space_ADataReader DataReader;

        CDR_Short i1 = 10;
        CDR_Short i2 = 10;
        CDR_Long i3 = 100;
        CDR_Long i4 = 100;
        CDR_LongLong i5 = 1000;
        CDR_LongLong i6 = 1000;
        CDR_UnsignedShort i7 = 10;
        CDR_UnsignedShort i8 = 10;
        CDR_UnsignedLong i9 = 100;
        CDR_UnsignedLong i10 = 100;
        CDR_UnsignedLongLong i11 = 1000;
        CDR_UnsignedLongLong i12 = 1000;
        CDR_Char c0 = 'a';
        CDR_String c1 = "abc";
        CDR_Boolean c2 = true;
        CDR_Float c3 = 10.901f;
        CDR_Double c4 = 23.234d;
        CDR_LongDouble c5 = 12.23456432235d;
        CDR_Short arr[10] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};

};

extern const char *space_ATYPENAME;

REDA_DEFINE_SEQUENCE_STRUCT(space_ASeq, space_A);

REDA_DEFINE_SEQUENCE_IN_C(space_ASeq, space_A);

NDDSUSERDllExport extern RTI_BOOL
space_A_initialize(space_A *sample)
{
    CDR_Primitive_init_Short(&sample->i1);
    CDR_Primitive_init_Short(&sample->i2);
    CDR_Primitive_init_Long(&sample->i3);
    CDR_Primitive_init_Long(&sample->i4);
    CDR_Primitive_init_LongLong(&sample->i5);
    CDR_Primitive_init_LongLong(&sample->i6);
    CDR_Primitive_init_UnsignedShort(&sample->i7);
    CDR_Primitive_init_UnsignedShort(&sample->i8);
    CDR_Primitive_init_UnsignedLong(&sample->i9);
    CDR_Primitive_init_UnsignedLong(&sample->i10);
    CDR_Primitive_init_UnsignedLongLong(&sample->i11);
    CDR_Primitive_init_UnsignedLongLong(&sample->i12);
    CDR_Primitive_init_Char(&sample->c0);

        if (!CDR_String_initialize(&sample->c1, (255)))
        {
            return RTI_FALSE;
        }

    CDR_Primitive_init_Boolean(&sample->c2);
    CDR_Primitive_init_Float(&sample->c3);
    CDR_Primitive_init_Double(&sample->c4);
    CDR_Primitive_init_LongDouble(&sample->c5);

        CDR_Primitive_init_Array(
                sample->arr, ((10) * CDR_SHORT_SIZE));


    return RTI_TRUE;
}

NDDSUSERDllExport extern RTI_BOOL
space_A_finalize(space_A *sample)
{
    UNUSED_ARG(sample);
        CDR_String_finalize(&sample->c1);





        {
                RTI_UINT32 i;

                for (i = 0; i < (10); i++)
                {
                    if (!CDR_Short_copy(&dst->arr[i],
                                        &src->arr[i]))
                    {
                        return RTI_FALSE;
                    }
                }
        }

    return RTI_TRUE;
}

#ifdef NDDS_USER_DLL_EXPORT
#if (defined(RTI_WIN32) || defined(RTI_WINCE))
/* If the code is building on Windows, stop exporting symbols. */
#undef NDDSUSERDllExport
#define NDDSUSERDllExport
#endif
#endif

#endif /* hxx */

```

##### **case3：**

```c++
module space{
	module A{
		struct B{
			short a=10;
		};
	};
};
```

**生成结果：**

```
/*
WARNING: THIS FILE IS AUTO-GENERATED. DO NOT MODIFY.

This file was generated from case_for_GenCode.idl using "idltoc".
The idltoc tool is part of the RTI Data Distribution Service distribution.
For more information, type 'idltoc -help' at a command shell
or consult the RTI Data Distribution Service manual.
*/
#ifndef case_for_GenCode_h
#define case_for_GenCode_h

#ifndef rti_me_cpp_hxx
#include "rti_me_cpp.hxx"
#endif

#ifdef NDDS_USER_DLL_EXPORT
#if (defined(RTI_WIN32) || defined(RTI_WINCE))
/* If the code is building on Windows, start exporting symbols. */
#undef NDDSUSERDllExport
#define NDDSUSERDllExport __declspec(dllexport)
#endif
#else
#undef NDDSUSERDllExport
#define NDDSUSERDllExport
#endif

struct space_A_BSeq;
class space_A_BTypeSupport;
class space_A_BDataWriter;
class space_A_BDataReader;

class space_A_B
{
public:
    typedef struct space_A_BSeq Seq;
    typedef space_A_BTypeSupport TypeSupport;
    typedef space_A_BDataWriter DataWriter;
    typedef space_A_BDataReader DataReader;

        CDR_Short a = 10;

};

extern const char *space_A_BTYPENAME;

REDA_DEFINE_SEQUENCE_STRUCT(space_A_BSeq, space_A_B);

REDA_DEFINE_SEQUENCE_IN_C(space_A_BSeq, space_A_B);

NDDSUSERDllExport extern RTI_BOOL
space_A_B_initialize(space_A_B *sample)
{
    CDR_Primitive_init_Short(&sample->a);

    return RTI_TRUE;
}

NDDSUSERDllExport extern RTI_BOOL
space_A_B_finalize(space_A_B *sample)
{
    UNUSED_ARG(sample);
    return RTI_TRUE;
}

#ifdef NDDS_USER_DLL_EXPORT
#if (defined(RTI_WIN32) || defined(RTI_WINCE))
/* If the code is building on Windows, stop exporting symbols. */
#undef NDDSUSERDllExport
#define NDDSUSERDllExport
#endif
#endif

#endif /* hxx */

```

