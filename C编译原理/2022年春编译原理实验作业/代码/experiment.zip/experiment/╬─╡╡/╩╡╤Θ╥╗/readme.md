# 实验一测试方法描述

### 一、使用方法

生成抽象语法树并格式化输出的启动类是experiment/src/ast/MIDL2AST.java

输入和输出文件的路径分别是：

![image-20230618155319950](E:\homework\experiment\文档\实验一\assets\image-20230618155319950.png)

**使用idea里的antlr4插件检查语法是否有问题：**

使用的例子：

module a{struct c{std::space1::space2 b=1;int64 d[10]=[1,2];unsigned long long ans=1|2^3&4>>5+6*7/8%~9;};};

生成的树：

![image-20230618174936625](E:\homework\experiment\文档\实验一\assets\image-20230618174936625.png)

**antlr4没有报错说明语法定义没有问题**

### 二、测试用例

共16条测试用例如下

```c++
struct a;
struct a{};
struct a;struct b;
struct a{int b;char c='T';float d;short e;char f;string g;boolean h;};
struct a{char b, c;short d[10];};
struct a{double b;struct type{}id;};
struct a{char b;int64 c;struct type{}id;};
struct a{std::space1::space2 b;std::space3::space4 c;};
module a{struct b{int c;};};
struct a{int64 b[2*5]=[1,2,3];};
struct a{int64 b = 1|2|3;int64 c = 1^2^3;int64 d = 1&2&3;int64 e = 1>>2<<3;};
struct a{int64 b = 1+2-3;int64 c = 1*2%4/3;};
struct a{int64 b = -1, c = +0.5, d = ~0;};
struct a{int64 b[10] = [1|2, 3^4, 5&6, 7>>8, 9<<10,11+12,13+14,15*16,17/18,19%20];};
struct a{int64 b = 100; float c = 0.9e-10;char d='\t';string e="eeee";boolean f = true;};
module a{struct c{std::space1::space2 b=1;int64 d[10]=[1,2];unsigned long long ans=1|2^3&4>>5+6*7/8%~9;};};
```

### 三、生成结果

兄弟节点的缩进保持一致

```
===========================================================
Test case1: struct a;
ASTParseTree:
specification(
    struct( 
        ID:a 
    )
 ) 
===========================================================
Test case1: struct a{};
ASTParseTree:
specification(
        struct( 
            ID:a 
        ) 
 ) 
===========================================================
Test case1: struct a;struct b;
ASTParseTree:
specification(
    struct( 
        ID:a 
    )
    struct( 
        ID:b 
    )
 ) 
===========================================================
Test case1: struct a{int b;char c='T';float d;short e;char f;string g;boolean h;};
ASTParseTree:
specification(
        struct( 
            ID:a 
            member(
                namespace( 
                    int
                ) 
                ID:b
            )
            member(
                char 
                ID:c
                value=('T'
                )
            )
            member(
                float
                ID:d
            )
            member(
                short
                ID:e
            )
            member(
                char 
                ID:f
            )
            member(
                string 
                ID:g
            )
            member(
                boolean 
                ID:h
            )
        ) 
 ) 
===========================================================
Test case1: struct a{char b, c;short d[10];};
ASTParseTree:
specification(
        struct( 
            ID:a 
            member(
                char 
                ID:b
                ID:c
            )
            member(
                short
                array(
                    ID:d10
                )
            )
        ) 
 ) 
===========================================================
Test case1: struct a{double b;struct type{}id;};
ASTParseTree:
specification(
        struct( 
            ID:a 
            member(
                double
                ID:b
            )
            member(
                struct( 
                    ID:type 
                ) 
                ID:id
            )
        ) 
 ) 
===========================================================
Test case1: struct a{char b;int64 c;struct type{}id;};
ASTParseTree:
specification(
        struct( 
            ID:a 
            member(
                char 
                ID:b
            )
            member(
                int64
                ID:c
            )
            member(
                struct( 
                    ID:type 
                ) 
                ID:id
            )
        ) 
 ) 
===========================================================
Test case1: struct a{std::space1::space2 b;std::space3::space4 c;};
ASTParseTree:
specification(
        struct( 
            ID:a 
            member(
                namespace( 
                    std
                    space1
                    space2
                ) 
                ID:b
            )
            member(
                namespace( 
                    std
                    space3
                    space4
                ) 
                ID:c
            )
        ) 
 ) 
===========================================================
Test case1: module a{struct b{int c;};};
ASTParseTree:
specification(
    module( 
        ID:a 
        member: (
                struct( 
                    ID:b 
                    member(
                        namespace( 
                            int
                        ) 
                        ID:c
                    )
                ) 
        )
    )
 ) 
===========================================================
Test case1: struct a{int64 b[2*5]=[1,2,3];};
ASTParseTree:
specification(
        struct( 
            ID:a 
            member(
                int64
                array(
                    ID:b
                    *(
                        2 5
                    )
                    arrayValues(
                        1 2 3 )
                )
            )
        ) 
 ) 
===========================================================
Test case1: struct a{int64 b = 1|2|3;int64 c = 1^2^3;int64 d = 1&2&3;int64 e = 1>>2<<3;};
ASTParseTree:
specification(
        struct( 
            ID:a 
            member(
                int64
                ID:b
                value=(
                    |(
                        1
                    |(
                        23
                    )
                    )
                )
            )
            member(
                int64
                ID:c
                value=(
                    ^(
                        1
                    ^(
                        23
                    )
                    )
                )
            )
            member(
                int64
                ID:d
                value=(
                    &(
                        1
                    &(
                        23
                    )
                    )
                )
            )
            member(
                int64
                ID:e
                value=(
                    >>(
                        1 
                    <<(
                        2 3
                    )
                    )
                )
            )
        ) 
 ) 
===========================================================
Test case1: struct a{int64 b = 1+2-3;int64 c = 1*2%4/3;};
ASTParseTree:
specification(
        struct( 
            ID:a 
            member(
                int64
                ID:b
                value=(
                    +(
                        1 
                    -(
                        2 3
                    )
                    )
                )
            )
            member(
                int64
                ID:c
                value=(
                    *(
                        1 
                    %(
                        2 
                    /(
                        4 3
                    )
                    )
                    )
                )
            )
        ) 
 ) 
===========================================================
Test case1: struct a{int64 b = -1, c = +0.5, d = ~0;};
ASTParseTree:
specification(
        struct( 
            ID:a 
            member(
                int64
                ID:b
                value=(
                    -(
                        1
                    )
                )
                ID:c
                value=(
                    +(
                        0.5
                    )
                )
                ID:d
                value=(
                    ~(
                        0
                    )
                )
            )
        ) 
 ) 
===========================================================
Test case1: struct a{int64 b[10] = [1|2, 3^4, 5&6, 7>>8, 9<<10,11+12,13+14,15*16,17/18,19%20];};
ASTParseTree:
specification(
        struct( 
            ID:a 
            member(
                int64
                array(
                    ID:b10
                    arrayValues(
                        
                        |(
                            12
                        ) 
                        ^(
                            34
                        ) 
                        &(
                            56
                        ) 
                        >>(
                            7 8
                        ) 
                        <<(
                            9 10
                        ) 
                        +(
                            11 12
                        ) 
                        +(
                            13 14
                        ) 
                        *(
                            15 16
                        ) 
                        /(
                            17 18
                        ) 
                        %(
                            19 20
                        ) )
                )
            )
        ) 
 ) 
===========================================================
Test case1: struct a{int64 b = 100; float c = 0.9e-10;char d='\t';string e="eeee";boolean f = true;};
ASTParseTree:
specification(
        struct( 
            ID:a 
            member(
                int64
                ID:b
                value=(100
                )
            )
            member(
                float
                ID:c
                value=(0.9e-10
                )
            )
            member(
                char 
                ID:d
                value=('\t'
                )
            )
            member(
                string 
                ID:e
                value=("eeee"
                )
            )
            member(
                boolean 
                ID:f
                value=(true
                )
            )
        ) 
 ) 
===========================================================
Test case1: module a{struct c{std::space1::space2 b=1;int64 d[10]=[1,2];unsigned long long ans=1|2^3&4>>5+6*7/8%~9;};};
ASTParseTree:
specification(
    module( 
        ID:a 
        member: (
                struct( 
                    ID:c 
                    member(
                        namespace( 
                            std
                            space1
                            space2
                        ) 
                        ID:b
                        value=(1
                        )
                    )
                    member(
                        int64
                        array(
                            ID:d10
                            arrayValues(
                                1 2 )
                        )
                    )
                    member(
                        unsigned long long
                        ID:ans
                        value=(
                            |(
                                1
                                ^(
                                    2
                                    &(
                                        3
                                        >>(
                                            4 
                                            +(
                                                5 
                                                *(
                                                    6 
                                                /(
                                                    7 
                                                %(
                                                    8 
                                                    ~(
                                                        9
                                                    )
                                                )
                                                )
                                                )
                                            )
                                        )
                                    )
                                )
                            )
                        )
                    )
                ) 
        )
    )
 ) 

```

