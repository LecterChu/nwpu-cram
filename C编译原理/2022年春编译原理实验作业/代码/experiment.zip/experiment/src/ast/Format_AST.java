package ast;

import antlrGen.MIDLBaseVisitor;
import antlrGen.MIDLParser;
import java.util.Objects;

/**
 *  AST formatter 进行抽象语法树的格式化输出
 */
public class Format_AST extends MIDLBaseVisitor<String> {

    public String astParseTree = "";
    public StringBuilder ast = new StringBuilder("");

    /**
     * specification -> definition { definition }
     * @param ctx
     */
    public String visitSpecification(MIDLParser.SpecificationContext ctx, int level) {
        ast.append("    ".repeat(Math.max(0, level)));
        ast.append("specification( \n");
        for (int i = 0; i < ctx.getChildCount(); i++)
            visit(ctx.getChild(i));
        ast.append(" ) ");
        return null;
    }

    /**
     * definiton -> type_decl“;”| module “;”
     * @param ctx
     */
    public String visitDefinition(MIDLParser.DefinitionContext ctx) {
        visit(ctx.getChild(0));
        return null;
    }

    /***
     * module -> “module”ID “{” definition { definition } “}”
     * @param ctx
     */
    public String visitModule(MIDLParser.ModuleContext ctx, int level) {
        System.out.println("LINE:" + ctx.getStart().getLine());  //check
        ast.append("    ".repeat(Math.max(0, level))).append("module(").append("    ".repeat(Math.max(0, level)));
        ast.append("ID:").append(ctx.getChild(1).getText()).append("\n");
        for(int i = 3;i < ctx.getChildCount()-1;i++)
            visit(ctx.getChild(i));
        ast.append("    ".repeat(Math.max(0, level))).append(")\n");
        return null;
    }

    /**
     * type_decl -> struct_type | “struct” ID
     * @param ctx
     */
    public String visitType_decl(MIDLParser.Type_declContext ctx, int level) {
        if (ctx.getChildCount() == 1)
            visit(ctx.getChild(0));
        else {
            ast.append("    ".repeat(Math.max(0, level))).append("struct(\n").append("    ".repeat(Math.max(0, level)));
            ast.append("ID:").append(ctx.ID().getText()).append("\n");
            ast.append("    ".repeat(Math.max(0, level))).append(")\n");
        }
        return null;
    }

    /***
     * struct_type->“struct” ID “{”   member_list “}”
     * @param ctx
     */
    public String visitStruct_type(MIDLParser.Struct_typeContext ctx, int level) {
        ast.append("    ".repeat(Math.max(0, level))).append("struct(\n").append("    ".repeat(Math.max(0, level)));
        ast.append("ID:").append(ctx.getChild(1).getText()).append("\n");
        visit(ctx.getChild(3));
        ast.append("    ".repeat(Math.max(0, level))).append(")\n");
        return null;
    }

    /**
     * member_list{ type_spec declarators “;” }
     * @param ctx
     */
    public String visitMember_list(MIDLParser.Member_listContext ctx, int level) {
        int n = ctx.getChildCount();
        if (n == 0)
            return null;
        else {
            for (int i = 0; i < n / 3; i++) {
                ast.append("    ".repeat(Math.max(0, level))).append("member(\n");
                visit(ctx.getChild(3 * i));
                visit(ctx.getChild(3 * i + 1));
                ast.append("    ".repeat(Math.max(0, level))).append(")\n");
            }
        }
        return null;
    }

    /**
     * type_spec -> scoped_name | base_type_spec | struct_type
     * @param ctx
     */
    public String visitType_spec(MIDLParser.Type_specContext ctx, int level) {
        visit(ctx.getChild(0));
        return null;
    }

    /**
     * scoped_name -> [“::”] ID {“::” ID }
     * @param ctx
     */
    public String visitScoped_name(MIDLParser.Scoped_nameContext ctx, int level) {
        ast.append("    ".repeat(Math.max(0, level)));
        ast.append("namespace(\n");
        int i;
        if(Objects.equals(ctx.getChild(0).getText(), "::"))
            i = 1;
        else i = 0;
        for (; i < ctx.getChildCount(); i += 2)
            ast.append("    ".repeat(Math.max(0, level))).append(ctx.getChild(i).getText()).append("\n");
        ast.append("    ".repeat(Math.max(0, level))).append(")\n");
        return null;
    }

    /**
     * base_type_spec->floating_pt_type|integer_type|“char”|“string”|“boolean”
     * @param ctx
     */
    public String visitBase_type_spec(MIDLParser.Base_type_specContext ctx, int level) {
        //终结符
        if (ctx.getChild(0).getChildCount() == 0) {
            ast.append("    ".repeat(Math.max(0, level)));
            ast.append(ctx.getChild(0).getText()).append("\n");
        }
        else
            visit(ctx.getChild(0));
        return null;
    }

    /**
     * floating_pt_type -> “float” | “double” | “long double”
     * @param ctx
     */
    public String visitFloating_pt_type(MIDLParser.Floating_pt_typeContext ctx, int level) {
        ast.append("    ".repeat(Math.max(0, level)));
        ast.append(ctx.getChild(0).getText()).append("\n");
        return null;
    }

    /**
     * integer_type -> signed_int | unsigned_int
     * @param ctx
     */
    public String visitInteger_type(MIDLParser.Integer_typeContext ctx, int level) {
        visit(ctx.getChild(0));
        return null;
    }

    /**
     * signed_int->(“short”|“int16”)|(“long”|“int32”)|(“long long”|“int64”)|“int8”
     * @param ctx
     */
    public String visitSigned_int(MIDLParser.Signed_intContext ctx, int level) {
        ast.append("    ".repeat(Math.max(0, level)));
        ast.append(ctx.getChild(0).getText()).append("\n");
        return null;
    }

    /**
     * unsigned_int -> (“unsigned short”| “uint16”)| (“unsigned long”| “uint32”)| (“unsigned long long” | “uint64”)| “uint8”
     * @param ctx
     */
    public String visitUnsigned_int(MIDLParser.Unsigned_intContext ctx, int level) {
        ast.append("    ".repeat(Math.max(0, level)));
        ast.append(ctx.getChild(0).getText()).append("\n");
        return null;
    }

    /**
     * declarators -> declarator {“,” declarator }
     * @param ctx
     */
    public String visitDeclarators(MIDLParser.DeclaratorsContext ctx, int level) {
        int n = ctx.getChildCount();
        for(int i = 0;i < n;i++)
            if(ctx.getChild(i).getChildCount()!=0)
                visit(ctx.getChild(i));
        return null;
    }

    /**
     * declarator -> simple_declarator | array_declarator
     * @param ctx
     */
    public String visitDeclarator(MIDLParser.DeclaratorContext ctx, int level) {
        visit(ctx.getChild(0));
        return null;
    }

    /**
     * simple_declarator -> ID [“=” or_expr]
     * @param ctx
     */
    public String visitSimple_declarator(MIDLParser.Simple_declaratorContext ctx, int level) {

        if (ctx.getChildCount() != 1) {
            ast.append("    ".repeat(Math.max(0, level))).append("=(\n").append("    ".repeat(Math.max(0, level)));
            ast.append("ID:").append(ctx.getChild(0).getText()).append("\n");
            visit(ctx.or_expr());
            ast.append("    ".repeat(Math.max(0, level))).append(")\n");
        }
        else {
            ast.append("    ".repeat(Math.max(0, level)));
            ast.append("ID:").append(ctx.getChild(0).getText()).append("\n");
        }
        return null;
    }

    /**
     * array_declarator -> ID “[” or_expr “]” [“=” exp_list ]
     * @param ctx
     */
    public String visitArray_declarator(MIDLParser.Array_declaratorContext ctx, int level) {
        ast.append("    ".repeat(Math.max(0, level))).append("array(\n").append("    ".repeat(Math.max(0, level)));
        ast.append("ID:").append(ctx.getChild(0).getText()).append("\n");
        visit(ctx.getChild(2));
        if (ctx.getChildCount() != 4)
            visit(ctx.exp_list());
        ast.append("    ".repeat(Math.max(0, level))).append(")\n");
        return null;
    }

    /**
     * exp_list -> “[” or_expr { “,”or_expr } “]”
     * @param ctx
     */
    public String visitExp_list(MIDLParser.Exp_listContext ctx, int level) {
        ast.append("    ".repeat(Math.max(0, level))).append("arrayValues(\n");
        int n = ctx.getChildCount();
        for (int i = 0; i < n; i ++)
            if(ctx.getChild(i).getChildCount()>0)
                visit(ctx.getChild(i));
        ast.append("    ".repeat(Math.max(0, level))).append(")\n");
        return null;
    }

    /**
     * or_expr -> xor_expr {“|” xor_expr }
     * @param ctx
     */
    public String visitOr_expr(MIDLParser.Or_exprContext ctx, int level) {
        int n = ctx.getChildCount();
        if(n > 1) {
            for (int i = 1; i < n; i += 2) {
                ast.append("    ".repeat(Math.max(0, level))).append("|(\n");
                visit(ctx.getChild(i - 1));
                if (i == n - 2)
                    visit(ctx.getChild(i + 1));
            }
            for (int i = 1; i < n; i += 2)
                ast.append("    ".repeat(Math.max(0, level))).append(")\n");
        }
        else visit(ctx.getChild(0));
        return null;
    }

    /**
     * xor_expr -> and_expr {“^” and_expr }
     * @param ctx
     */
    public String visitXor_expr(MIDLParser.Xor_exprContext ctx, int level) {
        int n = ctx.getChildCount();
        if(n > 1) {
            for (int i = 1; i < n; i += 2) {
                ast.append("    ".repeat(Math.max(0, level))).append("^(\n");
                visit(ctx.getChild(i - 1));
                if (i == n - 2)
                    visit(ctx.getChild(i + 1));
            }
            for (int i = 1; i < n; i += 2)
                ast.append("    ".repeat(Math.max(0, level))).append(")\n");
        }
        else visit(ctx.getChild(0));
        return null;
    }

    /**
     * and_expr -> shift_expr {“&”shift_expr }
     * @param ctx
     */
    public String visitAnd_expr(MIDLParser.And_exprContext ctx, int level) {
        int n = ctx.getChildCount();
        if(n > 1) {
            for (int i = 1; i < n; i += 2) {
                ast.append("    ".repeat(Math.max(0, level))).append("&(\n");
                visit(ctx.getChild(i - 1));
                if (i == n - 2)
                    visit(ctx.getChild(i + 1));
            }
            for (int i = 1; i < n; i += 2)
                ast.append("    ".repeat(Math.max(0, level))).append(")\n");
        }
        else visit(ctx.getChild(0));
        return null;
    }

    /**
     * shift_expr -> add_expr { (“>>” | “<<”) add_expr }
     * @param ctx
     */
    public String visitShift_expr(MIDLParser.Shift_exprContext ctx, int level) {
        int n = ctx.getChildCount();
        if(n > 1) {
            for (int i = 1; i < n; i += 2) {
                ast.append("    ".repeat(Math.max(0, level)));
                ast.append(ctx.getChild(i).getText()).append("\n");
                visit(ctx.getChild(i - 1));
                if (i == n - 2)
                    visit(ctx.getChild(i + 1));
            }
            for (int i = 1; i < n; i += 2)
                ast.append("    ".repeat(Math.max(0, level))).append(")\n");
        }
        else visit(ctx.getChild(0));
        return null;
    }

    /**
     * add_expr -> mult_expr {(“+” | “-”)  mult_expr }
     * @param ctx
     */
    public String visitAdd_expr(MIDLParser.Add_exprContext ctx, int level) {
        int n = ctx.getChildCount();
        if(n > 1) {
            for (int i = 1; i < n; i += 2) {
                ast.append("    ".repeat(Math.max(0, level)));
                ast.append(ctx.getChild(i).getText()).append("(\n");
                visit(ctx.getChild(i - 1));
                if (i == n - 2)
                    visit(ctx.getChild(i + 1));
            }
            for (int i = 1; i < n; i += 2)
                ast.append("    ".repeat(Math.max(0, level))).append(")\n");
        }
        else visit(ctx.getChild(0));
        return null;
    }

    /**
     * mult_expr -> unary_expr { (“*” |“/”|“%”) unary_expr }
     * @param ctx
     */
    public String visitMult_expr(MIDLParser.Mult_exprContext ctx, int level) {
        int n = ctx.getChildCount();
        if(n > 1) {
            for (int i = 1; i < n; i += 2) {
                ast.append("    ".repeat(Math.max(0, level)));
                ast.append(ctx.getChild(i).getText()).append("(\n");
                visit(ctx.getChild(i - 1));
                if (i == n - 2)
                    visit(ctx.getChild(i + 1));
            }
            for (int i = 1; i < n; i += 2)
                ast.append("    ".repeat(Math.max(0, level))).append(")\n");
        }
        else visit(ctx.getChild(0));
        return null;
    }

    /**
     * unary_expr -> [“-”| “+” | “~”] literal
     * @param ctx
     */
    public String visitUnary_expr(MIDLParser.Unary_exprContext ctx, int level) {

        if (ctx.getChildCount() != 1) {
            ast.append("    ".repeat(Math.max(0, level)));
            ast.append(ctx.getChild(0).getText()).append("(\n");
        }
        visit(ctx.literal());
        if (ctx.getChildCount() != 1)
            ast.append("    ".repeat(Math.max(0, level))).append(")\n");
        return null;
    }

    /**
     * literal -> INTEGER | FLOATING_PT | CHAR | STRING | BOOLEAN
     * @param ctx
     */
    public String visitLiteral(MIDLParser.LiteralContext ctx, int level) {
        ast.append("    ".repeat(Math.max(0, level)));
        ast.append(ctx.getChild(0)).append("\n");
        return null;
    }
}

