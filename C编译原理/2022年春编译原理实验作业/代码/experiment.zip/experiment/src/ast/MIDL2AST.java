package ast;

import antlrGen.*;
import org.antlr.v4.runtime.tree.*;
import org.antlr.v4.runtime.*;
import java.io.*;

/**
 * 格式化输出AST
 */
public class MIDL2AST{
    private static final String inputFileName = "./input/testcase_for_exp1.txt";
    private static final String outputFileName = "./output/SyntaxOut.txt";
    public static void main(String[] args) throws Exception {
        File inputFile = new File(inputFileName);
        if(inputFile.exists() && inputFile.isFile()) {
            System.out.println("Workplace: " + System.getProperties().getProperty("user.dir"));
            System.out.println("Successfully read " + inputFileName + "\n");
        }
        else {
            System.out.println("Invalid input file!");
            return;
        }
        BufferedReader bufferedReader = new BufferedReader(new FileReader(inputFile));
        File outputFile = new File(outputFileName);
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(outputFile));

        String line;
        int cnt = 1;
        while((line = bufferedReader.readLine()) != null) {
            System.out.println("Test case" + cnt + ": " + line);

            CharStream input = CharStreams.fromString(line);
            MIDLLexer lexer = new MIDLLexer(input);
            CommonTokenStream tokens = new CommonTokenStream(lexer);
            MIDLParser parser = new MIDLParser(tokens);
            ParseTree tree = parser.specification();
            My_ASTVisitor ag = new My_ASTVisitor();
            ag.visit(tree);

            System.out.println("ASTParseTree:\n" +ag.astParseTree);
            System.out.println("===========================================================");

            bufferedWriter.write("===========================================================\n");
            bufferedWriter.write("Test case" + cnt + ": " + line + "\n");
            bufferedWriter.write("ASTParseTree:\n");
            bufferedWriter.write(ag.astParseTree + "\n");
            bufferedWriter.flush();
        }
        bufferedReader.close();
        bufferedWriter.close();
    }
}
