package check;
import symtab.*;
import antlrGen.MIDLBaseVisitor;
import antlrGen.MIDLParser;

import java.util.ArrayList;
import java.util.Objects;

/**
 *  语义分析,计算收集信息插入符号表
 *
 */
public class SemanticCheck extends MIDLBaseVisitor<String> {

    //符号表相关
    public SymbolTable symbolTable = new SymbolTable();
    public ErrorRecorder errorRecorder = new ErrorRecorder();
    //错误类型
    public static final int redefined = 0;
    public static final int undefined = 1;
    public static final int typeError = 2;
    public static final int overflow  = 3;
    public static final int outIndex  = 4;
    //当前的module和struct
    public ArrayList<String> tempModule=new ArrayList<String>();
    public ArrayList<String> tempStruct=new ArrayList<String>();
    //当前有属性等待赋值的节点
    public SymbolNode tempNode = new SymbolNode();
    public String lastStruct = "";
    public ArrayList<SymbolNode> tempNodes=new ArrayList<SymbolNode>();
    //当前正负号
    public boolean isPos = true;
    //是否舍弃当前节点
    public boolean abandoned=false;

    String typeLoc(String type)
    {
        String loc = "";
        String []types={"float","double","long double", "unsigned short", "uint16","unsigned long", "uint32"
                    ,"unsigned long long" , "uint64","uint8","short","int16","long","int32"
                    ,"long long","int64","int8","char", "string", "boolean"};
        int i = 0;
        if(type.startsWith("Array"))
            type=type.substring(6,type.length()-1);

        for(;i < types.length;i++)
            if(types[i].equals(type))
                break;

        if(i <= 2) loc = "FLOATING_PT";
        else if(i <= 16) loc = "INTEGER";
        else if(i == 17) loc = "CHAR";
        else if(i == 18) loc = "STRING";
        else if(i == 19) loc = "BOOLEAN";
        else loc = "SCOPED";
        return loc;
    }


    /**
     * specification -> definition { definition }
     * @param ctx
     */
    @Override
    public String visitSpecification(MIDLParser.SpecificationContext ctx) {
        for (int i = 0; i < ctx.getChildCount(); i++) {
            tempModule.clear();
            visit(ctx.getChild(i));
        }
        return null;
    }

    /**
     * definiton -> type_decl“;”| module “;”
     * @param ctx
     */
    @Override
    public String visitDefinition(MIDLParser.DefinitionContext ctx) {
        visit(ctx.getChild(0));
        if(ctx.getChild(0).getText().startsWith("struct"))
            if(tempStruct.size() > 1)
                tempStruct.remove(tempStruct.size()-1);
        else
            if(tempModule.size()>1)
                tempModule.remove(tempModule.size()-1);

        return null;
    }

    /***
     * module -> “module”ID “{” definition { definition } “}”
     * @param ctx
     * @return
     */
    @Override
    public String visitModule(MIDLParser.ModuleContext ctx) {

        SymbolNode symbolNode = new SymbolNode();
        symbolNode.setName(ctx.getChild(1).getText());
        symbolNode.setType("module");
        if(tempModule.size() > 0)
            symbolNode.setModuleName(tempModule.toString());

        SymbolNode result = symbolTable.lookupSt(symbolNode);
        if(result == null)
            symbolTable.insertST(symbolNode);
        else
            errorRecorder.addError(ctx.getStart().getLine()+":"+ctx.getStart().getCharPositionInLine(),"module",ctx.getChild(1).getText(),redefined,null);

        tempModule.add(ctx.getChild(1).getText());

        for(int i = 3;i < ctx.getChildCount()-1;i++)
            visit(ctx.getChild(i));

        return null;
    }

    /**
     * type_decl -> struct_type | “struct” ID
     * @param ctx
     * @return
     */
    @Override
    public String visitType_decl(MIDLParser.Type_declContext ctx) {
        if (ctx.getChildCount() == 1) {
            lastStruct="";
            tempStruct.clear();
            visit(ctx.getChild(0));
        }
        else {
            SymbolNode symbolNode = new SymbolNode();
            symbolNode.setName(ctx.getChild(1).getText());
            symbolNode.setType("struct");

            if(tempModule.size() > 0)
                symbolNode.setModuleName(tempModule.toString());

            SymbolNode result = symbolTable.lookupSt(symbolNode);
            if(result==null)
                symbolTable.insertST(symbolNode);
            else
                errorRecorder.addError(ctx.getStart().getLine()+":"+ctx.getStart().getCharPositionInLine(),"struct",ctx.getChild(1).getText(),redefined,null);
        }
        return null;
    }

    /***
     * struct_type->“struct” ID “{”   member_list “}”
     * @param ctx
     */
    @Override
    public String visitStruct_type(MIDLParser.Struct_typeContext ctx) {

        SymbolNode sn = new SymbolNode();
        sn.setName(ctx.getChild(1).getText());
        sn.setType("struct");

        if(tempStruct.size() > 0)
            sn.setStructName(tempStruct.toString());
        if(tempModule.size() > 0)
            sn.setModuleName(tempModule.toString());

        SymbolNode result = symbolTable.lookupSt(sn);
        if(result==null)
            symbolTable.insertST(sn);
        else
            errorRecorder.addError(ctx.getStart().getLine()+":"+ctx.getStart().getCharPositionInLine(),"struct",ctx.getChild(1).getText(),redefined,null);

        tempStruct.add(ctx.getChild(1).getText());
        lastStruct=tempStruct.get(tempStruct.size()-1);

        visit(ctx.getChild(3));
        lastStruct=tempStruct.get(tempStruct.size()-1);
        tempStruct.remove(tempStruct.size()-1);

        return null;
    }

    /**
     * member_list{ type_spec declarators “;” }
     * @param ctx
     */
    @Override
    public String visitMember_list(MIDLParser.Member_listContext ctx) {
        int n = ctx.getChildCount();
        if (n == 0)
            return null;
        else
            for (int i = 0; i < n / 3; i++) {
                visit(ctx.getChild(3 * i));
                visit(ctx.getChild(3 * i + 1));
                lastStruct="";
                tempNode=new SymbolNode();
            }
        return null;
    }

    /**
     * type_spec -> scoped_name | base_type_spec | struct_type
     * @param ctx
     */
    @Override
    public String visitType_spec(MIDLParser.Type_specContext ctx) {
        visit(ctx.getChild(0));
        return null;
    }

    /**
     * scoped_name -> [“::”] ID {“::” ID }
     * 最后一个是struct
     * @param ctx
     */
    @Override
    public String visitScoped_name(MIDLParser.Scoped_nameContext ctx) {
        ArrayList<String> namespaces = new ArrayList<String>();
        int i;
        if(Objects.equals(ctx.getChild(0).getText(), "::"))
            i = 1;
        else i = 0;

        for (; i < ctx.getChildCount()-2; i += 2)
            namespaces.add(ctx.getChild(i).getText());

        String structName = ctx.getChild(i).getText();
        String moduleName = null;
        if(namespaces.size()>0)
            moduleName = namespaces.toString();
        if(namespaces.size()==0)
            moduleName = tempModule.toString();

        SymbolNode symbolNode = new SymbolNode();
        symbolNode.setName(structName);
        symbolNode.setType("struct");
        if(moduleName!=null)
            symbolNode.setModuleName(moduleName);
        SymbolNode res = symbolTable.lookupSt(symbolNode);
        if(res==null){
            errorRecorder.addError(ctx.getStart().getLine()+":"+ctx.getStart().getCharPositionInLine(),"struct",structName,undefined,null);
        }
        else{
            tempNode.setType(res.getModuleName()+"::"+res.getStructName()+"::"+structName);
            tempNode.setStructName(res.getStructName());
            if(moduleName!=null)
                tempNode.setModuleName(moduleName);
        }

        return null;
    }

    /**
     * base_type_spec->floating_pt_type|integer_type|“char”|“string”|“boolean”
     * @param ctx
     */
    @Override
    public String visitBase_type_spec(MIDLParser.Base_type_specContext ctx) {
        if (ctx.getChild(0).getChildCount() == 0)
            tempNode.setType(ctx.getChild(0).getText());
        else visit(ctx.getChild(0));
        return null;
    }

    /**
     * floating_pt_type -> “float” | “double” | “long double”
     * @param ctx
     */
    @Override
    public String visitFloating_pt_type(MIDLParser.Floating_pt_typeContext ctx) {
        tempNode.setType(ctx.getChild(0).getText());
        return null;
    }

    /**
     * integer_type -> signed_int | unsigned_int
     * @param ctx
     */
    @Override
    public String visitInteger_type(MIDLParser.Integer_typeContext ctx) {
        visit(ctx.getChild(0));
        return null;
    }

    /**
     * signed_int->(“short”|“int16”)|(“long”|“int32”)|(“long long”|“int64”)|“int8”
     * @param ctx
     */
    @Override
    public String visitSigned_int(MIDLParser.Signed_intContext ctx) {
        tempNode.setType(ctx.getChild(0).getText());
        return null;
    }

    /**
     * unsigned_int -> (“unsigned short”| “uint16”)| (“unsigned long”| “uint32”)| (“unsigned long long” | “uint64”)| “uint8”
     * @param ctx
     */
    @Override
    public String visitUnsigned_int(MIDLParser.Unsigned_intContext ctx) {
        tempNode.setType(ctx.getChild(0).getText());
        return null;
    }

    /**
     * declarators -> declarator {“,” declarator }
     * @param ctx
     */
    @Override
    public String visitDeclarators(MIDLParser.DeclaratorsContext ctx) {
        int n = ctx.getChildCount();
        for(int i = 0;i < n;i++)
        {
            if(ctx.getChild(i).getChildCount()!=0)
            {
                abandoned = false;
                visit(ctx.getChild(i));
                if(tempNodes.size()>0 && !abandoned)
                    symbolTable.insertST(tempNodes.get(tempNodes.size()-1));
            }
        }
        tempNodes.clear();
        return null;
    }

    /**
     * declarator -> simple_declarator | array_declarator
     * @param ctx
     */
    @Override
    public String visitDeclarator(MIDLParser.DeclaratorContext ctx) {
        visit(ctx.getChild(0));
        return null;
    }

    /**
     * simple_declarator -> ID [“=” or_expr]
     * @param ctx
     * @return
     */
    @Override
    public String visitSimple_declarator(MIDLParser.Simple_declaratorContext ctx) {
        SymbolNode sn=new SymbolNode();
        sn.setName(ctx.getChild(0).getText());
        if(tempModule.size()>0)
            sn.setModuleName(tempModule.toString());

        if(tempNode.getType()==null)
            tempNode.setType(lastStruct);
        if(tempStruct.size()>0)
            sn.setStructName(tempStruct.toString());

        SymbolNode res= symbolTable.lookupSt(sn);

        if(res!=null)
            errorRecorder.addError(ctx.getStart().getLine()+":"+ctx.getStart().getCharPositionInLine(),tempNode.getType(),ctx.getChild(0).getText(),redefined,null);
        else{
            sn.setType(tempNode.getType());
            if (ctx.getChildCount() == 1 && sn.getType().length() > 0)
                symbolTable.insertST(sn);
            else if(ctx.getChildCount() > 1)
                tempNodes.add(sn);
        }
        if (ctx.getChildCount() != 1 && res==null)
            visit(ctx.or_expr());
        return null;
    }

    /**
     * array_declarator -> ID “[” or_expr “]” [“=” exp_list ]
     * @param ctx
     */
    @Override
    public String visitArray_declarator(MIDLParser.Array_declaratorContext ctx) {
        SymbolNode sn=new SymbolNode();
        sn.setName(ctx.getChild(0).getText());
        sn.setStructName(tempStruct.toString());
        sn.setModuleName(tempModule.toString());
        SymbolNode res= symbolTable.lookupSt(sn);

        if(res!=null)
            errorRecorder.addError(ctx.getStart().getLine()+":"+ctx.getStart().getCharPositionInLine(),tempNode.getType(),ctx.getChild(0).getText(),redefined,null);
        else{
            sn.setType("Array<"+tempNode.getType()+">");
            tempNodes.add(sn);
        }
        if(res==null){
            visit(ctx.getChild(2));
            if(tempNodes.get(tempNodes.size()-1).getVal()==null)
                return null;
            String arrayLength = tempNodes.get(tempNodes.size()-1).getVal();
            String calLengths = Calculator.calAns(arrayLength,"INTEGER",true);
            int calLength = -1;
            if(calLengths.equals("overflow")){
                errorRecorder.addError(ctx.getStart().getLine()+":"+ctx.getStart().getCharPositionInLine(),"INTEGER",arrayLength ,overflow,null);
                abandoned=true;
            }
            else if(!calLengths.equals("TypeError")){
                calLength = Integer.parseInt(calLengths);
                tempNodes.get(tempNodes.size()-1).setVal(calLength+"#");
            }
            else errorRecorder.addError(ctx.getStart().getLine()+":"+ctx.getStart().getCharPositionInLine(),"Array",arrayLength,typeError,null);
            int eles=0;
            if (ctx.getChildCount() != 4) {
                for(int i=0;i < ctx.exp_list().getChildCount();i++)
                {
                    if(ctx.exp_list().getChild(i).getChildCount()>0)
                        eles++;
                }
                if(eles>calLength && calLength!=-1){
                    errorRecorder.addError(ctx.getStart().getLine()+":"+ctx.getStart().getCharPositionInLine(),"Array",tempNodes.get(tempNodes.size()-1).getName(),outIndex,null);
                    abandoned = true;
                }
                visit(ctx.exp_list());
            }
        }
        return null;
    }

    /**
     * exp_list -> “[” or_expr { “,”or_expr } “]”
     * @param ctx
     */
    @Override
    public String visitExp_list(MIDLParser.Exp_listContext ctx) {
        int n = ctx.getChildCount();
        for (int i = 0; i < n; i ++)
            if(ctx.getChild(i).getChildCount()>0)
            {
                visit(ctx.getChild(i));
                String preValues = tempNodes.get(tempNodes.size()-1).getVal();
                tempNodes.get(tempNodes.size()-1).setVal(preValues+"#");
            }
        return null;
    }

    /**
     * or_expr -> xor_expr {“|” xor_expr }
     * @param ctx
     */
    @Override
    public String visitOr_expr(MIDLParser.Or_exprContext ctx) {
        int n = ctx.getChildCount();
        if(n > 1) {
            for (int i = 1; i < n; i += 2) {
                visit(ctx.getChild(i - 1));
                String preVal = tempNodes.get(tempNodes.size()-1).getVal();
                tempNodes.get(tempNodes.size()-1).setVal(preVal+"|");
                if (i == n - 2)
                    visit(ctx.getChild(i + 1));
            }
        }
        else visit(ctx.getChild(0));
        return null;
    }

    /**
     * xor_expr -> and_expr {“^” and_expr }
     * @param ctx
     */
    @Override
    public String visitXor_expr(MIDLParser.Xor_exprContext ctx) {
        int n = ctx.getChildCount();
        if(n > 1)
            for (int i = 1; i < n; i += 2) {
                visit(ctx.getChild(i - 1));
                String preVal = tempNodes.get(tempNodes.size()-1).getVal();
                tempNodes.get(tempNodes.size()-1).setVal(preVal+"^");
                if (i == n - 2)
                    visit(ctx.getChild(i + 1));
            }
        else visit(ctx.getChild(0));
        return null;
    }

    /**
     * and_expr -> shift_expr {“&”shift_expr }
     * @param ctx
     */
    @Override
    public String visitAnd_expr(MIDLParser.And_exprContext ctx) {
        int n = ctx.getChildCount();
        if(n > 1)
            for (int i = 1; i < n; i += 2) {
                visit(ctx.getChild(i - 1));
                String preVal = tempNodes.get(tempNodes.size()-1).getVal();
                tempNodes.get(tempNodes.size()-1).setVal(preVal+"&");
                if (i == n - 2)
                    visit(ctx.getChild(i + 1));
            }

        else visit(ctx.getChild(0));
        return null;
    }

    /**
     * shift_expr -> add_expr { (“>>” | “<<”) add_expr }
     * @param ctx
     */
    @Override
    public String visitShift_expr(MIDLParser.Shift_exprContext ctx) {
        int n = ctx.getChildCount();
        if(n > 1)
            for (int i = 1; i < n; i += 2) {
                //>>或<<
                visit(ctx.getChild(i - 1));
                String preVal = tempNodes.get(tempNodes.size()-1).getVal();
                tempNodes.get(tempNodes.size()-1).setVal(preVal+ctx.getChild(i).getText());
                if (i == n - 2)
                    visit(ctx.getChild(i + 1));
            }

        else visit(ctx.getChild(0));
        return null;
    }

    /**
     * add_expr -> mult_expr {(“+” | “-”)  mult_expr }
     * @param ctx
     */
    @Override
    public String visitAdd_expr(MIDLParser.Add_exprContext ctx) {
        int n = ctx.getChildCount();
        if(n > 1)
            for (int i = 1; i < n; i += 2) {
                visit(ctx.getChild(i - 1));
                String preVal = tempNodes.get(tempNodes.size()-1).getVal();
                tempNodes.get(tempNodes.size()-1).setVal(preVal+ctx.getChild(i).getText());
                if (i == n - 2)
                    visit(ctx.getChild(i + 1));
            }

        else visit(ctx.getChild(0));
        return null;
    }

    /**
     * mult_expr -> unary_expr { (“*” |“/”|“%”) unary_expr }
     * @param ctx
     */
    @Override
    public String visitMult_expr(MIDLParser.Mult_exprContext ctx) {
        int n = ctx.getChildCount();
        if(n > 1)
            for (int i = 1; i < n; i += 2) {
                //*” |“/”|“%”
                visit(ctx.getChild(i - 1));
                String preVal = tempNodes.get(tempNodes.size()-1).getVal();
                tempNodes.get(tempNodes.size()-1).setVal(preVal+ctx.getChild(i).getText());
                if (i == n - 2)
                    visit(ctx.getChild(i + 1));
            }

        else visit(ctx.getChild(0));
        return null;
    }

    /**
     * unary_expr -> [“-”| “+” | “~”] literal
     * @param ctx
     */
    @Override
    public String visitUnary_expr(MIDLParser.Unary_exprContext ctx) {

        if(ctx.getChild(0).getText().equals("-"))
            isPos = false;
        else if(ctx.getChild(0).getText().equals("+"))
            isPos = true;
        if (ctx.getChildCount() != 1) {
            String preVal = tempNodes.get(tempNodes.size()-1).getVal();
            if(preVal==null)
                tempNodes.get(tempNodes.size()-1).setVal(ctx.getChild(0).getText());
            else
                tempNodes.get(tempNodes.size()-1).setVal(preVal + ctx.getChild(0).getText());
        }
        visit(ctx.literal());
        return null;
    }

    /**
     * literal -> INTEGER | FLOATING_PT | CHAR | STRING | BOOLEAN
     * @param ctx
     */
    @Override
    public String visitLiteral(MIDLParser.LiteralContext ctx) {

        String checkType = tempNodes.get(tempNodes.size()-1).getType();
        boolean typeTrue=false;
        if(ctx.INTEGER()!=null){
            //看看是不是在赋值数组下标
            if(tempNodes.get(tempNodes.size()-1).getType().startsWith("Array")){
                if(!isPos) {
                    errorRecorder.addError(ctx.getStart().getLine()+":"+ctx.getStart().getCharPositionInLine(),"INTEGER","-"+ctx.getChild(0).getText(),overflow,null);
                }
                else if(Calculator.checkOverFlow(ctx.getChild(0).getText(),isPos))
                    errorRecorder.addError(ctx.getStart().getLine()+":"+ctx.getStart().getCharPositionInLine(),"INTEGER",ctx.getChild(0).getText(),overflow,null);
                else typeTrue=true;
            }
            else if(!typeLoc(checkType).equals("INTEGER"))
                errorRecorder.addError(ctx.getStart().getLine()+":"+ctx.getStart().getCharPositionInLine(),"INTEGER",ctx.getChild(0).getText(),typeError,typeLoc(checkType));
            else if(Calculator.checkOverFlow(ctx.getChild(0).getText(),isPos)){
                String prefix="";
                if(!isPos)prefix+="-";
                errorRecorder.addError(ctx.getStart().getLine()+":"+ctx.getStart().getCharPositionInLine(),"INTEGER",prefix + ctx.getChild(0).getText(),overflow,null);
            }
            else typeTrue=true;
        }
        else if(ctx.FLOATING_PT()!=null){
            if(!typeLoc(checkType).equals("FLOATING_PT"))
                errorRecorder.addError(ctx.getStart().getLine()+":"+ctx.getStart().getCharPositionInLine(),"FLOATING_PT",ctx.getChild(0).getText(),typeError,typeLoc(checkType));
            else typeTrue=true;
        }
        else if(ctx.CHAR()!=null){
            if(!typeLoc(checkType).equals("CHAR"))
                errorRecorder.addError(ctx.getStart().getLine()+":"+ctx.getStart().getCharPositionInLine(),"CHAR",ctx.getChild(0).getText(),typeError,typeLoc(checkType));
            else typeTrue=true;
        }
        else if(ctx.STRING()!=null){
            if(!typeLoc(checkType).equals("STRING"))
                errorRecorder.addError(ctx.getStart().getLine()+":"+ctx.getStart().getCharPositionInLine(),"STRING",ctx.getChild(0).getText(),typeError,typeLoc(checkType));
            else typeTrue=true;
        }
        else if(ctx.BOOLEAN()!=null){
            if(!typeLoc(checkType).equals("BOOLEAN"))
                errorRecorder.addError(ctx.getStart().getLine()+":"+ctx.getStart().getCharPositionInLine(),"BOOLEAN",ctx.getChild(0).getText(),typeError,typeLoc(checkType));
            else typeTrue=true;
        }

        if(!typeTrue)
            abandoned=true;
        if(typeTrue){
            String preVal = tempNodes.get(tempNodes.size()-1).getVal();
            if(preVal==null)
                tempNodes.get(tempNodes.size()-1).setVal(ctx.getChild(0).getText());
            else {
                tempNodes.get(tempNodes.size()-1).setVal(preVal + ctx.getChild(0).getText());
            }
        }
        return null;
    }
}
