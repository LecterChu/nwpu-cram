package symtab;

import antlrGen.MIDLLexer;
import antlrGen.MIDLParser;
import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;
import check.SemanticCheck;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 * MIDL转换抽象语法树的启动类
 * Input:按行读取输入文件
 * Output:输出格式化抽象语法树到对应文件
 */
public class TestSymbolTable {

    private static final String inputFileName = "./txt/inputLines.txt";

    public static void test() throws IOException {
        BufferedReader bufferedReader = new BufferedReader( new FileReader(inputFileName));
        StringBuilder codes= new StringBuilder();
        String line;
        int cnt = 1;
        while((line = bufferedReader.readLine()) != null) {
            System.out.println("["+cnt + "]: " + line);
            codes.append(line);
            cnt++;
        }

        //词法检查-语法检查
        CharStream input = CharStreams.fromString(codes.toString());
        MIDLLexer lexer = new MIDLLexer(input);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        MIDLParser parser = new MIDLParser(tokens);
        ParseTree tree = parser.specification();
        //遍历分析树-语义检查
        SemanticCheck mc = new SemanticCheck();
        mc.visit(tree);

        bufferedReader.close();

    }
    public static void main(String[] args) throws Exception {

        test();

    }
}
