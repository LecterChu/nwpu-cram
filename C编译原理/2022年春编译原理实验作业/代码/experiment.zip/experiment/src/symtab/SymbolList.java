package symtab;

import java.util.ArrayList;

/**
 * 符号表中的元素链
 */
public class SymbolList {
    public SymbolNode head;
    public SymbolList()
    {
        head = new SymbolNode();
    }

    /**
     * 头插
     * @param sn
     */
    public void insertNode(SymbolNode sn)
    {
        sn.setNext(head.getNext());
        head.setNext(sn);
    }

    public SymbolNode getHead()
    {
        return head;
    }

    /**
     * tofind中非null的值进行匹配
     * @param toFind
     */
    public SymbolNode findNode(SymbolNode toFind)
    {
        SymbolNode tp = head;
        while((tp=tp.getNext())!=null){
            if(toFind.getName()!=null && !(toFind.getName().equals(tp.getName())))
                continue;
            if(toFind.getModuleName()!=null && !(toFind.getModuleName().equals(tp.getModuleName())))
                continue;
            if(toFind.getStructName()!=null && !(toFind.getStructName().equals(tp.getStructName())))
                continue;
            if(toFind.getType()!=null && !(toFind.getType().equals(tp.getType())))
                continue;
            if(toFind.getVal()!=null && !(toFind.getVal().equals(tp.getVal())))
                continue;
            break;
        }
        return tp;
    }

    /**
     * tofind中非null的值进行匹配所有的
     * @param toFind
     */
    public ArrayList<SymbolNode> findNodes(SymbolNode toFind)
    {
        ArrayList<SymbolNode> ans = new ArrayList<SymbolNode>();

        SymbolNode tp = head;
        while((tp=tp.getNext())!=null){
            if(toFind.getName()!=null && !(toFind.getName().equals(tp.getName())))
                continue;
            if(toFind.getModuleName()!=null && !(toFind.getModuleName().equals(tp.getModuleName())))
                continue;
            if(toFind.getStructName()!=null && !(toFind.getStructName().equals(tp.getStructName())))
                continue;
            if(toFind.getType()!=null && !(toFind.getType().equals(tp.getType())))
                continue;
            if(toFind.getVal()!=null && !(toFind.getVal().equals(tp.getVal())))
                continue;
            ans.add(tp);
        }
        return ans;
    }


    @Override
    public String toString()
    {
        SymbolNode tp = head.getNext();
        StringBuilder sb = new StringBuilder();
        while(tp!=null){
            sb.append(tp.toString()).append("\n");
            tp = tp.getNext();
        }
        return sb.toString();
    }

}
