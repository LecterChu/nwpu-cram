package net.mooctest;

import static org.junit.Assert.*;
import org.junit.Test;

/*
 * 
 * 开发者测试，测试下一天用例
 * 理解和掌握使用 Eclemma 软件测试工具对 Java 语言编写的程序进行语句覆盖测试。
 * 
 * @author Bao Zepeng
 * @version 1.0
 * 
 */

public class DemoTest {

	@Test
	public void test() {
		Date d1 = new Date(10, 9, 2022); // 测试正确示例
		Date d2 = new Date(10, 10, 2022);// 测试下一天
		Date d3 = new Date(2, 28, 2020); // 测试闰年2月28日
		Date d4 = new Date(12, 31, 2019);// 测试闰年前一年的最后一天
		Date d5 = new Date(2, 29, -1); // 测试公元前的闰年
		Date d6 = new Date(12, 31, -1); // 测试公元前1年最后一天
		Date d7 = new Date(10, 9, 2022); // 用于比较当前天数
		Year year = new Year(2022); // 创建年份
		Month month = new Month(10, year); // 创建月份
		Day day = new Day(9, month); // 创建天数
		d1.printDate(); // 打印日期
		Nextday nextday = new Nextday(); // 创建Nextday的对象
		assertEquals("10/9/2022", d1.toString()); // 比较打印的日期
		assertEquals(true, d1.equals(d7)); // 比较相同的天数
		assertEquals(false, d1.equals(d2)); // 比较不同的天数
		assertEquals(false, d1.equals(new Date(10, 9, 2021))); // 比较不同的年份
		assertEquals(false, d1.equals(new Date(9, 9, 2022))); // 比较不同的月份
		assertEquals(day, d1.getDay()); // 测试天数
		assertEquals(month, d1.getMonth()); // 测试月份
		assertEquals(year, d1.getYear()); // 测试年份
		assertEquals(d2, Nextday.nextDay(d1)); // 测试是否为下一天
		Nextday.nextDay(d3); // 测试闰年2月28日
		Nextday.nextDay(d4); // 测试闰年前一年的最后一天
		Nextday.nextDay(d5); // 测试公元前的闰年
		Nextday.nextDay(d6); // 测试公元前1年最后一天

	}

	// 测试天数是否有效
	@Test(expected = IllegalArgumentException.class)
	public void testIsDayValid() {
		Date d = new Date(10, 40, 2022);
	}

	// 测试月份是否有效
	@Test(expected = IllegalArgumentException.class)
	public void testIsMonthValid() {
		Date d = new Date(13, 21, 2022);
	}

	// 测试年份是否有效
	@Test(expected = IllegalArgumentException.class)
	public void testIsYearValid() {
		Date d = new Date(12, 21, 0); // 公元前1年的后一年应该是公元1年，不存在0年的说法
	}

}
