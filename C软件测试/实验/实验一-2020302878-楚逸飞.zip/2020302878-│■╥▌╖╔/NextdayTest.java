import static org.junit.Assert.*;

import org.junit.Test;

import org.hamcrest.CoreMatchers;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;

import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;

/**
 * 
 * @author 楚逸飞
 * @version 1.0
 */
public class NextdayTest {
	
	/*
	 * MONTH_EXCEPTION will be thrown when the month is not valid
	 */
	private final String MONTH_EXCEPTION = "Not a valid month";
	
	/*
	 * DAY_EXCEPTION will be thrown when the day is not valid
	 */
	private final String DAY_EXCEPTION = "Not a valid day";
	
	/*
	 * YEAR_EXCEPTION will be thrown when the year is not valid
	 */
	private final String YEAR_EXCEPTION = "Not a valid year";
	
	/*
	 * 等价类测试（有效类）
	 */
    @Test(timeout = 1000)
    public void firstTest() {
 
        Date date; //初始日期
        Date fact; //实际执行结果
        Date expected; //所期望的正确结果
        
    	/*
    	 * common
    	 */
        date = new Date(12, 5, 2021);
        fact = Nextday.nextDay(date);
        fact.printDate();
        expected = new Date(12, 6, 2021);
        Assert.assertEquals(fact, expected);
        
    	/*
    	 * 测试month 31天的月份
    	 */
        date = new Date(1, 31, 2021);
        fact = Nextday.nextDay(date);
        fact.printDate();
        expected = new Date(2, 1, 2021);
        Assert.assertEquals(fact, expected);
        
    	/*
    	 * 测试month 30天的月份
    	 */
        date = new Date(4, 30, 2021);
        fact = Nextday.nextDay(date);
        fact.printDate();
        expected = new Date(5, 1, 2021);
        Assert.assertEquals(fact, expected);
        
    	/*
    	 * year测试
    	 */
        date = new Date(12, 31, 2020);
        fact = Nextday.nextDay(date);
        fact.printDate();
        expected = new Date(1, 1, 2021);
        Assert.assertEquals(expected, fact);
        
    	/*
    	 * 特殊年份 公元前后
    	 */
        date = new Date(12, 31, -1);
        fact = Nextday.nextDay(date);
        fact.printDate();
        expected = new Date(1, 1, 1);
        Assert.assertEquals(expected, fact);
        
    	/*
    	 * 闰年 测试三种情况 主要是的是4的倍数但不是100的倍数或者是400的倍数 测试2000 2020
    	 */
        date = new Date(2, 29, 2020);
        fact = Nextday.nextDay(date);
        fact.printDate();
        expected = new Date(3, 1, 2020);
        Assert.assertEquals(expected, fact);
        
        date = new Date(2, 29, 2000);
        fact = Nextday.nextDay(date);
        fact.printDate();
        expected = new Date(3, 1, 2000);
        Assert.assertEquals(expected, fact);
        
        
    	/*
    	 * 非闰年
    	 */
        date = new Date(2, 28, 2021);
        fact = Nextday.nextDay(date);
        fact.printDate();
        expected = new Date(3, 1, 2021);
        Assert.assertEquals(expected, fact);
 
        String s = date.toString();

        Year year = new Year(2021);
        year.equals(null);
        Month month = new Month(12, year);
        month.equals(null);
        Day day = new Day(5, month);
        day.equals(null);
        Nextday nextDay = new Nextday();
        
        date.equals(null);
    }

	/*
	 * 等价类测试（无效类）
	 */
    @Test
    public void secondTest() {
        Object[][] testArr = {
        		//month day year
                {3, 1, 0, YEAR_EXCEPTION},//没有公元0年
                {-1, 1, 2021, MONTH_EXCEPTION},//month 不能为非正整数
                {13, 1, 2021, MONTH_EXCEPTION},//month 不能大于12
                {29, 2, 2100, MONTH_EXCEPTION},//测试特殊年份2100 属于既是4的倍数又是100的倍数 不是闰年 所以2月没有29日
                {1, -1, 2021, DAY_EXCEPTION},//day 不能为非正整数
                {2, 30, 2020, DAY_EXCEPTION},//2月没有30日
                {2, 29, 2021, DAY_EXCEPTION},//非闰年2月没有29
                {3, 32, 2021, DAY_EXCEPTION},//day不能大于31
                {4, 31, 2021, DAY_EXCEPTION}//小月没有31日
        };
        for (Object[] test : testArr) {
            try {
                Date date = new Date((int) test[0], (int) test[1], (int) test[2]);
                Date d = Nextday.nextDay(date);
                fail();
            } catch (IllegalArgumentException e) {
                assertThat(e.getMessage(), CoreMatchers.containsString((String) test[3]));
            }
        }
    }
}


