/* libyywrap - flex run-time support library "yywrap" function */

/* $Header: /a1/cvsadm/cvsroot/expsir/csubjects/flex/versions.alt/versions.seeded/v1/lib_src/libyywrap.c,v 1.1.1.1 2003/06/02 17:12:02 expsir Exp $ */

int yywrap()
	{
	return 1;
	}
